import { Component } from '@angular/core';

@Component({
  selector: 'app-shop',
  imports: [],
  template: `
    <p>
      shop works!
    </p>
  `,
  styles: ``,
})
export default class ShopComponent {}
