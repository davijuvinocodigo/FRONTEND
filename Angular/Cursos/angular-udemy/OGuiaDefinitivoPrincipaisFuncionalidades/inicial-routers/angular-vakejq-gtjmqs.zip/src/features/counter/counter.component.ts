import { Component } from '@angular/core';

@Component({
  selector: 'app-counter',
  imports: [],
  template: `
    <p>
      counter works!
    </p>
  `,
  styles: ``
})
export default class CounterComponent {}